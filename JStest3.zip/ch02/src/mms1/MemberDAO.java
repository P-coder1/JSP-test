package mms1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class MemberDAO {
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	
	public MemberDAO() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("JDBC ����̹� �ε� ����");
			e.printStackTrace();
		}
	}
	
	public void connection() {
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test_db?serverTimezone=UTC",
					"javaDB","javaDB");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			
			e.printStackTrace();
		}
	}
	public void close() {
		if(conn != null) {
			try {
				conn.close();
			}catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if( pstmt != null) {
			try {
				pstmt.close();
			}catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if(rs != null) {
			try {
				rs.close();
			}catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Member searchMemberByName(String name) {
		Member member = null;
		try {	
			connection();
			
			String sql = "select * from member1 where name = ? ";
			pstmt= conn.prepareStatement(sql);
			pstmt.setString(1, name);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				member = new Member();
				member.setName(rs.getString("name"));
				member.setAddr(rs.getString("addr"));
				member.setNation(rs.getString("nation"));
				member.setEmail(rs.getString("email"));
				member.setAge(rs.getInt("age"));
			}
		
		}catch (SQLException e) {
			System.out.println("SQL ���� ���� ");
			e.printStackTrace();
		}
		finally {
			close();
		}
		return member;
		
	}

	public ArrayList<Member> memberList() {
		// TODO Auto-generated method stub
		ArrayList<Member> list = new ArrayList<Member>();
		try {	
			connection();
			
			String sql = "select * from member1";
			pstmt= conn.prepareStatement(sql);

			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				Member member = new Member();
				member.setName(rs.getString("name"));
				member.setAddr(rs.getString("addr"));
				member.setNation(rs.getString("nation"));
				member.setEmail(rs.getString("email"));
				member.setAge(rs.getInt("age"));
				list.add(member);
			}
		
		}catch (SQLException e) {
			System.out.println("SQL ���� ���� ");
			e.printStackTrace();
		}
		finally {
			close();
		}
		return list;
	}

	public int insertMember(Member newMember) {
		// TODO Auto-generated method stub
		int insertCount = 0;
		String sql = "INSERT INTO member VALUSE(0,?,?,?,?,?)";
		try {
			connetion();
			pstmt = conn.perpareStatement(sql);
		}
		return 0;
	}
	
}
