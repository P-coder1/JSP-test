package mms1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;


public class memberManagement4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	

		Scanner sc = new Scanner(System.in);
		System.out.println("�˻��� �̸�: ");
		String name = sc.nextLine();
		sc.close();
				
		
		MemberDAO dao = new MemberDAO();
		Member member = dao.searchMemberByName(name);
		System.out.println(member);
		
		System.out.println("\nȸ�� ����Ʈ");
		ArrayList<Member> list = dao.memberList();
		for(Member m : list) {
			System.out.println(m);
		}
	}
}


