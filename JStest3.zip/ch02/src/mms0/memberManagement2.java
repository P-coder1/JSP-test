package mms0;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


public class memberManagement2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		
		Scanner sc = new Scanner(System.in);
		System.out.println("�˻��� ����: ");
		String nation = sc.nextLine();
		System.out.println("��������: ");
		int age = sc.nextInt();
		sc.close();
				
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test_db?serverTimezone=UTC",
					"javaDB","javaDB");
			
			String sql = "select * from member1 where nation = ? and age >= ? ";
			pstmt= conn.prepareStatement(sql);
			pstmt.setString(1, nation);
			pstmt.setInt(2,age );
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				System.out.print(rs.getString("name")+ "\t");
				System.out.print(rs.getString("addr")+ "\t");
				System.out.print(rs.getString("nation")+ "\t");
				System.out.print(rs.getString("email")+ "\t");
				System.out.println(rs.getInt("age"));
			}
		}catch(ClassNotFoundException e) {
				System.out.println("JDBC ����̹� �ε� ����");
		}catch (SQLException e) {
			System.out.println("SQL ���� ����");
			e.printStackTrace();
		}finally {
			if(conn != null) {
				try {
					conn.close();
				}catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if( pstmt != null) {
				try {
					pstmt.close();
				}catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(rs != null) {
				try {
					rs.close();
				}catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
}


