use mysql;

create user 'javaDB'@'localhost' identified by  'javaDB' ;

grant all on *.* to 'javaDB'@'localhost';

flush privileges;

create database test_db;