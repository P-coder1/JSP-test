package mema0;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class memberManagement0 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test_db?serverTimezone=UTC",
					"javaDB","javaDB");
			
			stmt= conn.createStatement();
			rs = stmt.executeQuery("select * from member1");
			
			while(rs.next()) {
				System.out.print(rs.getString("name")+ "\t");
				System.out.print(rs.getString("addr")+ "\t");
				System.out.print(rs.getString("nation")+ "\t");
				System.out.print(rs.getString("email")+ "\t");
				System.out.print(rs.getInt("age"));
			}
		}catch(ClassNotFoundException e) {
				System.out.println("JDBC ����̹� �ε� ����");
		}catch (SQLException e) {
			System.out.println("SQL ���� ����");
			e.printStackTrace();
		}finally {
			if(conn != null) {
				try {
					conn.close();
				}catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if( stmt != null) {
				try {
					stmt.close();
				}catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(rs != null) {
				try {
					rs.close();
				}catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
}


