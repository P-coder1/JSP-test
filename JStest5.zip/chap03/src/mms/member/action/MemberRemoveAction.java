package mms.member.action;

import java.util.Scanner;

public class MemberRemoveAction implements Action {

	@Override
	public void execute(Scanner sc) throws Exception {
		// TODO Auto-generated method stub

	}

}
