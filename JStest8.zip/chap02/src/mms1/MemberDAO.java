package mms1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class MemberDAO {
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	
	public MemberDAO() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("JDBC ����̹� �ε� ����");
			e.printStackTrace();
		}
	}
	
	public void connection() {
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test_db?serverTimezone=UTC",
					"javaDB","javaDB");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			
			e.printStackTrace();
		}
	}
	public void close() {
		if(conn != null) {
			try {
				conn.close();
			}catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if( pstmt != null) {
			try {
				pstmt.close();
			}catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if(rs != null) {
			try {
				rs.close();
			}catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Member searchMemberByName(String name) {
		Member member = null;
		String sql = "select * from member1 where name = ? "; // ���� 
		
		try {	
			connection(); // ���ؼ��� �ξ���
			
			
			pstmt= conn.prepareStatement(sql); // ������ Ʋ�� ����
			pstmt.setString(1, name);
			rs = pstmt.executeQuery(); // ������ ����
			
			if(rs.next()) {
				member = new Member(); // ����� ����
				member.setName(rs.getString("name"));
				member.setAddr(rs.getString("addr"));
				member.setNation(rs.getString("nation"));
				member.setEmail(rs.getString("email"));
				member.setAge(rs.getInt("age"));
			}
		
		}catch (SQLException e) {
			System.out.println("SQL ���� ���� ");
			e.printStackTrace();
		}
		finally {
			close();
		}
		return member;
		
	}

	public ArrayList<Member> memberList() {
		// TODO Auto-generated method stub
		ArrayList<Member> list = new ArrayList<Member>();
		try {	
			connection();
			
			String sql = "select * from member1"; // sql�� �ɹ�1�� DB���� �ҷ���
			pstmt= conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) { // while ������ �ٲ�
				Member member = new Member(); // ��� ����
				member.setName(rs.getString("name"));
				member.setAddr(rs.getString("addr"));
				member.setNation(rs.getString("nation"));
				member.setEmail(rs.getString("email"));
				member.setAge(rs.getInt("age"));
				list.add(member); // ��� ����Ʈ�� �ϳ��� add ��Ŵ
			}
		
		}catch (SQLException e) {
			System.out.println("SQL ���� ���� ");
			e.printStackTrace();
		}
		finally {
			close();
		}
		return list; // ����Ʈ���� ������
	}

	public int insertMember(Member newMember) {
		int insertCount = 0;
		String sql = "INSERT INTO member1 VALUE(0, ?,?,?,?,?)"; 
		
		try {
			connection();
				pstmt = conn.prepareStatement(sql); // ���� Ʋ�� �������
				pstmt.setString(1, newMember.getName()); //sql�� ?�� ä����
				pstmt.setString(2, newMember.getAddr());
				pstmt.setString(3, newMember.getNation());
				pstmt.setString(4, newMember.getEmail());
				pstmt.setInt(5, newMember.getAge());
				
				
				insertCount = pstmt.executeUpdate(); //������Ʈ ����
			} catch (Exception e) {
				e.printStackTrace();
		}finally {
			close();
		}
		
		return insertCount;
	}
	
	public int deleteMember(String name) {
		int deleteCount = 0;
		String sql = "delete from member1 where name = ?"; 
		
		try {
			connection();
				pstmt = conn.prepareStatement(sql); // ���� Ʋ�� �������
				pstmt.setString(1, name); //sql�� ?�� ä����
				
				deleteCount = pstmt.executeUpdate(); //������Ʈ ����
			} catch (Exception e) {
				e.printStackTrace();
		}finally {
			close();
		}
		
		return deleteCount;
	}
}

