package dao;

import java.sql.Connection;

public class DogDAO {
	Connection con;
	
	private static DogDAO dogDAO;
	
	private DogDAO() { // �����ڸ� �����̺����� ����
		
	}
	
	public void setConection(Connection con) {
		this.con = con;
	}
	public static DogDAO getInstance() {
		if(dogDAO == null) {
			dogDAO = new DogDAO();
		}
		
		return dogDAO;
	}
	
	public void setConnection(Connection con) {
		this.con = con;
	}
}
