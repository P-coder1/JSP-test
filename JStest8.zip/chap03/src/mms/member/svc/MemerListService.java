package mms.member.svc;

import java.sql.Connection;
import java.util.ArrayList;

import mms.member.dao.MemberDAO;
import mms.member.vo.Member;
import static mms.member.db.JdbcUtil.*;

public class MemerListService {
	
	public ArrayList<Member> getMemberList(){
		
		Connection con = getConnection();
		MemberDAO memberDAO = new MemberDAO(con);
		ArrayList<Member> memberList = memberDAO.selectmemberList();
		close(con);
		return memberList;
	}
}
